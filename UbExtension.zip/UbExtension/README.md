# Add to GCal

AddtoGCal is a Chrome extension that lets you add events to your various Google calendars.
It utilizes Google's quickAdd request format, the Google Chrome Api and JQuery.

Future enhancements:
Integrating Google calendar reminders in a to-do-list-esque fashion
Increase user control with event parameters

Chrome Webstore Link: https://chrome.google.com/webstore/detail/lfodkcaadjjbaliojcippghjfibodnil
Last published 12:30PM 2/19/2017
